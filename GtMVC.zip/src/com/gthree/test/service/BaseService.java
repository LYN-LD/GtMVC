package com.gthree.test.service;

/**
 * 公共service
 */
public class BaseService {
}
